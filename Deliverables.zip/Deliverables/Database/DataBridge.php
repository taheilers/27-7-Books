<?php
/*
 * Author: Richard A. Bolanos
 * Date Created: 4/30/2017
 * Description: Database Interaction Script
 */









//this is a class I am creating which will handle all the talk between the data base and the page....it is still a working progress
class DataInteraction{
    protected $dbInventory;
    protected $dbCostumers;
    protected $dbAdmins;
    function __construct() {
        $this->dbInventory = $this->Inventory();
        $this->dbAdmins = $this->Admins();
        $this->dbCostumers = $this->Costumers();
    }
    function Inventory(){
        $user = 'root';
        $pssw = '';
        $db =  new PDO("mysql:host=localhost;dbname=27/7 inventory", $user, $pssw);
        if($db != true){
            die("Unable to Open Databse Inventory");
        }
        return $db;
    }
    function Costumers(){
        $user = 'root';
        $pssw = '';
        $db =  new PDO("mysql:host=localhost;dbname=27/7 costumers", $user, $pssw);
        if($db != true){
            die("Unable to Open Databse Costumers");
        }
        return $db;
    }
    function Admins(){
        $user = 'root';
        $pssw = '';
        $db =  new PDO("mysql:host=localhost;dbname=27/7 admins", $user, $pssw);
        if($db != true){
            die("Unable to Open Databse Admins");
        }
        return $db;
    }
    protected function query($q, $dbName){
        $run = ($dbName == "costumer")? $this->dbCostumers->query($q): null;
        $run = ($dbName == "admin")? $this->dbAdmins->query($q): $run;
        $run = ($dbName == "inventory")? $this->dbInventory->query($q): $run;
       
        return $run;
    }
    function CreateTable($tb_Name, $design){
        $rslt = $this->query("Create Table ".$tb_Name.$design, "costumer");
        if($rslt != true){
            die("<br/>Error Creating Table ".$tb_Name);
        }
        echo 'Created Table '.$tb_Name.'<br/>';
    }
    //Finish
    function insertCostumer($FName, $LName, $Password, $UserID, $City, $CNY, $STATE, $street, $ZIP, $number, $Email){
      $rslt = $this->query("Insert into costumer_info(FName, LName, Password, UserID)"
              . "values('".$FName."','".$LName."','".$Password."','".$UserID."')", "costumer");
      
      if($rslt != true){
          echo 'There was an error inserting the records into the costumer_info';
      }
      else{
          $address = $this->query("Insert into customer_address(City, CNY, STATE, street, UserId, ZIP, Type)"
              . "values('".$City."','".$CNY."','".$STATE."','".$street."','".$UserID."','".$ZIP."', 'P')", "costumer");
      
          $phone = $this->query("Insert into customer_phone(number, Type, UserId) "
                  . "values('".$number."','P','".$UserID."')", "costumer");
          
          $email = $this->query("Insert into customer_email(email, Type, UserId)"
                  . "values('".$Email."','P', '".$UserID."')", "costumer");
          
          if($address != true && $phone != true && $email != true){
              echo 'somthing went wrong adding address ,phone, or email records';
          }
          else{
              echo 'Record were succesfully added';
          }
      }
    }
    //Needs Works
    function addCostumerPhone($number, $type, $UserId){
        $check = $this->dbCostumers->query("Select * from customer_phone where UserId ='".$UserId."'");
        $validEntry = true;
        foreach($check as $row){
            if($row["number"] == $number){
                echo 'The number you are trying to add already exist';
                $validEntry = false;
            }
        }
        if($type == "P" && $validEntry == true){
            foreach($check as $row){
                if($row["Type"] == "P"){
                    echo "<form action='' name='verifyChange' mwthod='POST'>"
                    . "<p>You already have a primary number set up do you wish to change it?</p>"
                    . "<input type='radio' value='Yes'> "
                    . "<input type='radio' value='No'>"
                    . "</form>";
                    return $this->cPhoneDec();
                }
                else{
                    $rslt = $this->query("Insert into customer_phone(number, Type, UserId)"
                            . "values('".$$number."','".$type."', '".$UserId."')", "costumer");
                    if($rslt != true){
                        echo 'There was an issue adding that phone number';
                    }
                    else{
                        echo 'The phone number was succesfully saved';
                    }
                }
            }
        }
        else if($type != "P" && $validEntry == true){
            $rslt = $this->query("Insert into customer_phone(number, Type, UserId)"
                            . "values('".$number."','".$type."', '".$UserId."')", "costumer");
                    if($rslt != true){
                        echo 'There was an issue adding that phone number';
                    }
                    else{
                        echo 'The phone number was succesfully saved';
                    }
        }
    }
    function cPhoneDec(){
        if($_POST["Yes" == true]){
            
        }
        else if($_POST["No"] == true){
            
        }
    }
    function addCostumerAddress(){
        
    }
    function searchBooks($critiria){
        $resultsISBN = false;
        if(preg_match('~[0-9]~', $critiria)){
            $resultsISBN = $this->dbInventory->query("Select * from books where ISBN='".$critiria."'");
        }
        $resultsTitle = $this->dbInventory->query("Select * from books where Title='".$critiria."'");
        if($resultsISBN != true && $resultsTitle != true){
            echo 'There was not match for your search in our database';
        }
        else if($resultsISBN == true){
            foreach($resultsISBN as $row){
                return $row;
            }
        }
        else if($resultsISBN != true && $resultsTitle == true){
            foreach($resultsTitle as $row){
                return $row;
            }
        }
    }
}

$db = new DataInteraction();
//$db->addCostumerPhone("5023227781", "S", "rbolanos1992");
$book = $db->searchBooks("1234567891234");
echo $book["Title"];


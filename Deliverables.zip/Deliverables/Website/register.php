<?
    include('header.html');
    include('nav.html');
?>

<form action="account.php">
    <label>Username<input type="text" name="username"></label><br>
    <label>Password<input type="password" name="password"></label><br>
    <label>Re-enter Password<input type="password" name="password"></label><br>
    <input type="submit" value="Create">
</form>
<br>
<p><a href="login.php">Login</a>.</p>
<? include('footer.html'); ?>